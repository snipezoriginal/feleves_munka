document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

 
    if (username && password) {
        window.location.href = "main_site.html"; 
    } else {
        alert("Kérjük, adja meg a felhasználónevet és a jelszót.");
    }
});

window.onload = function() {
    const circle = document.querySelector('.loading-circle');
    const video = document.querySelector('.background-video');
    const content = document.querySelector('.content');

    
    circle.addEventListener('animationend', function() {
       
        video.style.animation = "fade-out 2s ease-out forwards"; 

       
        content.classList.add('show-content');
    });
};